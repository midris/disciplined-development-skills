# Full CW baseline collection

Status: OWNER-ACCEPTED on 2026-09-08 — complete 99-observation baseline; evidence packaging/commit remains pending.
Owner statement: “baseline accepted”; the owner selected unchanged rewritten-CW candidate preparation next and deferred larger samples (possibly five).
Acceptance applies to all 81 fresh and 18 reused observations with their recorded caveats; original worksheet dispositions remain as recorded at scoring time.
81 of 81 new observations are collected, checked and scored; 0 remain.
Worktree: /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design
Branch: feature/cw-validation-design.
Frozen revision: dfd638ce5c1ac5f654110d05ce9138e5384d6afc.
Provider/model/effort: codex / gpt-5.6-sol / medium.
Fixed qualification capture directory: /private/tmp/skilltest-cw-catalog-qualification.YiAoRu.

[Qualification and reuse report](/private/tmp/skilltest-cw-catalog-qualification.YiAoRu/summary.md) supports 18 reused observations and 81 new observations, for 99 total.
The [reused evidence ledger](/private/tmp/skilltest-cw-baseline.ksDeiD/summary.md) remains authoritative for those original scores and timestamps; owner acceptance now covers both batches.
Do not copy, rescore or relabel the old records as fresh.
New observations run serially: repetitions 1–3 each traverse the approved mapping and skip its six reused conditions.
Fixed order, incidental date/path context and noncontemporaneous reuse remain disclosed sampling limits.
Collection also includes a laptop-sleep gap between commands 68 and 69; command 68 had completed before interruption, and only worksheet filling needed resumption. No provider retry was needed. Frozen inputs and qualified CLI version/digest were rechecked before command 69.

Review the [complete 81-command approval request](approval-commands.md).
Collection used the [CW runbook](/Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/cw-runbook.md), [mapping](/Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/cw-catalog.md) and linked routine recovery/scoring rules at the frozen revision above; live links now include handoff-only status updates.
The worksheet scenario comes from the selected config's prompt directory, not efforts/medium.
Record exact approval and the command document's hash before starting.
Owner approval: “approved, please continue”, recorded 2026-09-08 10:52:53 UTC after the command-batch review.
Approval applies to the unchanged 81-command document with SHA-256 `49c8b1e389600e1aa7a9ea31c8930d92adac0a77060106bc93bdf915982a6c2f`, Codex / gpt-5.6-sol / medium, frozen revision `dfd638ce5c1ac5f654110d05ce9138e5384d6afc` and its stated order/paths.
The approval request is preserved unchanged as the approved artifact; its pending-status text describes the request, not the current authorization.
Provider-free command audit passed for all 81 commands; [command-audit.json](command-audit.json) records the exact order, config/rubric hashes and approval-document SHA-256 `49c8b1e389600e1aa7a9ea31c8930d92adac0a77060106bc93bdf915982a6c2f`.
The frozen revision is pushed to origin/feature/cw-validation-design; the worktree remained clean through collection and the complete-set audit.
All 81 attempt directories were prepared empty; completed rows now link their retained evidence.
All run and attempt directories are scratch-only; inputs and accepted evidence remain protected.
All 81 new command approvals are exhausted. Handoff-only status/navigation edits follow the clean frozen audit; they do not change test inputs or scores.

## Complete baseline results for owner review

All 33 declared conditions have three scored observations: 81 fresh plus 18 referenced unchanged from the earlier ledger.
CLI: `codex-cli 0.153.4`, executable `/opt/homebrew/bin/codex`, SHA-256 `b973d440acac501fd2594a43e7ca9ce41e0a65b9dfb28d0d7a7837c99e1261e3`.
The primary counts below mean the declared semantic, transport, contract or discovery result; fidelity failures are separate and do not silently change that result.
These are small fixed samples, not pooled catalog effectiveness or reliability estimates.

| Purpose / condition | PASS | FAIL | INCONCLUSIVE | Evaluable | Fidelity FAIL |
|---|---:|---:|---:|---:|---:|
| CW-01 prose / current-DD | 3 | 0 | 0 | 3 | 1 |
| CW-01 positive discovery / current-DD | 3 | 0 | 0 | 3 | 1 |
| CW-01 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-02 prose / current-DD | 3 | 0 | 0 | 3 | 0 |
| CW-02 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-03 prose / current-DD | 3 | 0 | 0 | 3 | 0 |
| CW-03 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-04 prose / current-DD | 3 | 0 | 0 | 3 | 0 |
| CW-04 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-05 prose / current-DD | 3 | 0 | 0 | 3 | 1 |
| CW-05 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-06 prose / current-DD | 3 | 0 | 0 | 3 | 2 |
| CW-06 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-07 transport / current-DD | 3 | 0 | 0 | 3 | 1 |
| CW-07 transport / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-08 prose / current-DD | 3 | 0 | 0 | 3 | 3 |
| CW-08 prose / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-09 description classification / current-DD | 0 | 3 | 0 | 3 | 1 |
| CW-10 ownership contract / current-DD | 0 | 3 | 0 | 3 | 0 |
| CW-11 description classification / current-DD | 0 | 3 | 0 | 3 | 0 |
| CW-12 ownership contract / current-DD | 0 | 3 | 0 | 3 | 0 |
| CW-13 loaded composition / current-DD | 3 | 0 | 0 | 3 | 3 |
| CW-13 positive discovery / current-DD | 1 | 2 | 0 | 3 | 0 |
| CW-13 loaded composition / no-DD | 3 | 0 | 0 | 3 | 2 |
| CW-14 loaded composition / current-DD | 3 | 0 | 0 | 3 | 2 |
| CW-14 positive discovery / current-DD | 3 | 0 | 0 | 3 | 0 |
| CW-14 loaded composition / no-DD | 3 | 0 | 0 | 3 | 2 |
| CW-17 scope contract / current-DD | 0 | 3 | 0 | 3 | 0 |
| CW-17 non-trigger discovery / current-DD | 1 | 2 | 0 | 3 | 0 |
| CW-18 scope contract / current-DD | 3 | 0 | 0 | 3 | 0 |
| CW-18 positive discovery / current-DD | 3 | 0 | 0 | 3 | 3 |
| CW-19 prose / current-DD | 2 | 1 | 0 | 3 | 2 |
| CW-19 prose / no-DD | 0 | 3 | 0 | 3 | 0 |

### Findings and limits

- CW-01–08 prose/transport criteria pass with and without DD in every observation; those passing controls are not behavioral RED.
- CW-19 supplies a targeted no-DD padding-removal failure in all three observations. Current-DD removes that padding in all three, but one loses the exact mismatch-equality escalation boundary; that condition passes two of three overall.
- CW-09/11 description classification and CW-10/12 ownership extraction expose mismatches between current skill text and the required authoring composition/ownership contract. Source-faithful selection or truthful null extraction is not a model-reading failure.
- CW-17's response-only exception is absent from the supplied body; all three scope answers faithfully reflect that body but fail the desired contract. CW-18's durable-file scope passes all three.
- Loaded CW-13/14 lifecycle choices pass in both conditions. These are supplied-choice decisions attributed to writing-skills, not spontaneous discovery or performed authoring/validation.
- Native discovery passes three of three for CW-01, CW-14 and CW-18, one of three for CW-13, and one of three for CW-17's non-trigger. CW-13 failures concern full-body loading before the first substantive decision; later reads do not repair timing. Worksheets disclose the boundary between tentative framing and an actual go/no-go commitment for owner review.
- Fidelity failures in the table are extra narration under output-only/brief-notice constraints. Full-trace scoring catches these even when final.txt is compliant. All requested artifacts were readable; deterministic protocol is N/A.
- All three CW-18 guides were independently read in full. In repetitions 1–2, requested self-check commands did not expose guide content in their retained output; the actual saved artifact, not claimed self-verification, establishes delivery. Repetition 3 retains actual previews.
- Bundled and composition-mediated reads are disclosed rather than attributed solely to CW. Complete observable traces and returned source bytes do not prove hidden provider inputs, model-context delivery or internal method use. CW-14 no-DD repetition 1 has a specifically recorded raw-output versus model-reported truncation caveat.

The [complete-set mechanical audit](handoff-audit.md) verifies all 99 distinct bundles, 33 three-observation conditions, recorded CLI captures, exact invocation, artifact/prelaunch hashes, protected inputs, complete trace envelopes, serial execution within each batch and owned runtime cleanup.
The 81 new worksheets preserve generated provenance, have filled assessments and resolve their evidence links.
There were no infrastructure retries, invalid/excluded observations or unresolved cleanup; no accepted record or frozen test input was modified.
Provider and command stderr are empty; the qualified version-only PATH-alias warning and optional subject-tool lookup diagnostics remain disclosed, non-blocking where required controls passed.
The laptop-sleep gap, fixed order and noncontemporaneous reuse above limit causal comparisons.

No runner or process change was required by this batch.
The fresh handoff command `python3 -m pytest -q`, run from `skills/disciplined-development/hooks`, passed 263 tests with three skips; [retained output](hook-tests.txt).
The unchanged runner retains its prior 231-test verification; no harness/environment change or failed verification required a rerun.
Only the CW spec, runbook and catalog status/navigation were updated after collection; those edits are uncommitted. Main remains clean.
The [bounded handoff review](handoff-review.md) resolved stale status references and passed the final 239-link/count/scope check; no unresolved findings remain.
Retain full-trace scoring, separate purpose/fidelity ledgers and independent file inspection; do not add a new mechanism from these observations.
Next: preserve the accepted evidence durably and complete owner-authorized CW candidate preparation; qualification/reuse, freeze and exact-command approval precede candidate collection.
This completed handoff grants no additional provider call or shipped-skill change; subsequent owner-authorized candidate preparation is tracked in the live CW design.

## New observations

| Order | Attempt | Status / evidence |
|---|---|---|
| 1 | medium-r1-cw01-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw01-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw01-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 2 | medium-r1-cw01-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw01-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw01-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 3 | medium-r1-cw02-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw02-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw02-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 4 | medium-r1-cw02-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw02-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw02-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 5 | medium-r1-cw03-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw03-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw03-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 6 | medium-r1-cw03-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw03-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw03-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 7 | medium-r1-cw04-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw04-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw04-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 8 | medium-r1-cw04-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw04-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw04-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 9 | medium-r1-cw05-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw05-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw05-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 10 | medium-r1-cw05-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r1-cw05-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw05-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 11 | medium-r1-cw06-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw06-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw06-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 12 | medium-r1-cw06-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw06-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw06-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 13 | medium-r1-cw07-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw07-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw07-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 14 | medium-r1-cw07-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw07-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw07-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 15 | medium-r1-cw09-description | COMPLETED; semantic FAIL (target composition), source faithfulness/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw09-description/worksheet.md), [bundle path](attempts/medium-r1-cw09-description/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 16 | medium-r1-cw10-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw10-contract/worksheet.md), [bundle path](attempts/medium-r1-cw10-contract/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 17 | medium-r1-cw11-description | COMPLETED; semantic FAIL (target composition), source faithfulness/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw11-description/worksheet.md), [bundle path](attempts/medium-r1-cw11-description/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 18 | medium-r1-cw12-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw12-contract/worksheet.md), [bundle path](attempts/medium-r1-cw12-contract/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 19 | medium-r1-cw13-no-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r1-cw13-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw13-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 20 | medium-r1-cw13-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r1-cw13-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw13-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 21 | medium-r1-cw13-discovery | COMPLETED; discovery FAIL (CW PASS; WS full-load timing FAIL), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw13-discovery/worksheet.md), [bundle path](attempts/medium-r1-cw13-discovery/command-stdout.txt); exit 0, controls/cleanup PASS; optional git-log lookup failed, no retry. |
| 22 | medium-r1-cw14-no-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r1-cw14-no-dd/worksheet.md), [bundle path](attempts/medium-r1-cw14-no-dd/command-stdout.txt); exit 0, controls/cleanup PASS; raw-output versus self-reported truncation caveat recorded. |
| 23 | medium-r1-cw14-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r1-cw14-current-dd/worksheet.md), [bundle path](attempts/medium-r1-cw14-current-dd/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 24 | medium-r1-cw14-discovery | COMPLETED; discovery PASS (both targets), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw14-discovery/worksheet.md), [bundle path](attempts/medium-r1-cw14-discovery/command-stdout.txt); exit 0, controls/cleanup PASS; optional missing-directory lookup error, no retry. |
| 25 | medium-r1-cw17-contract | COMPLETED; semantic FAIL (response exception), body consistency/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r1-cw17-contract/worksheet.md), [bundle path](attempts/medium-r1-cw17-contract/command-stdout.txt); exit 0, controls/cleanup PASS. |
| 26 | medium-r1-cw18-contract | [PASS](attempts/medium-r1-cw18-contract/worksheet.md) — file scope and fidelity PASS |
| 27 | medium-r1-cw18-discovery | COMPLETED; discovery PASS (bundled CW read before file generation), fidelity FAIL (narration); [worksheet](attempts/medium-r1-cw18-discovery/worksheet.md); controls/cleanup PASS, independently inspected guide retained. |
| 28 | medium-r2-cw01-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw01-no-dd/worksheet.md); controls/cleanup PASS. |
| 29 | medium-r2-cw01-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw01-current-dd/worksheet.md); controls/cleanup PASS. |
| 30 | medium-r2-cw02-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw02-no-dd/worksheet.md); controls/cleanup PASS. |
| 31 | medium-r2-cw02-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw02-current-dd/worksheet.md); controls/cleanup PASS. |
| 32 | medium-r2-cw03-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw03-no-dd/worksheet.md); controls/cleanup PASS. |
| 33 | medium-r2-cw03-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw03-current-dd/worksheet.md); controls/cleanup PASS. |
| 34 | medium-r2-cw04-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw04-no-dd/worksheet.md); controls/cleanup PASS. |
| 35 | medium-r2-cw04-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw04-current-dd/worksheet.md); controls/cleanup PASS. |
| 36 | medium-r2-cw05-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw05-no-dd/worksheet.md); controls/cleanup PASS. |
| 37 | medium-r2-cw05-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw05-current-dd/worksheet.md); controls/cleanup PASS. |
| 38 | medium-r2-cw06-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw06-no-dd/worksheet.md); controls/cleanup PASS. |
| 39 | medium-r2-cw06-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw06-current-dd/worksheet.md); controls/cleanup PASS. |
| 40 | medium-r2-cw07-no-dd | COMPLETED; transport/prose PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw07-no-dd/worksheet.md); controls/cleanup PASS. |
| 41 | medium-r2-cw07-current-dd | COMPLETED; transport/prose PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw07-current-dd/worksheet.md); controls/cleanup PASS. |
| 42 | medium-r2-cw09-description | COMPLETED; semantic FAIL (target composition), source faithfulness/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw09-description/worksheet.md); controls/cleanup PASS. |
| 43 | medium-r2-cw10-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw10-contract/worksheet.md); controls/cleanup PASS. |
| 44 | medium-r2-cw11-description | COMPLETED; semantic FAIL (target composition), source faithfulness/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw11-description/worksheet.md); controls/cleanup PASS. |
| 45 | medium-r2-cw12-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw12-contract/worksheet.md); controls/cleanup PASS. |
| 46 | medium-r2-cw13-no-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw13-no-dd/worksheet.md); controls/cleanup PASS. |
| 47 | medium-r2-cw13-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw13-current-dd/worksheet.md); controls/cleanup PASS. |
| 48 | medium-r2-cw13-discovery | COMPLETED; discovery FAIL (CW and WS timing), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw13-discovery/worksheet.md); controls/cleanup PASS. |
| 49 | medium-r2-cw14-no-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw14-no-dd/worksheet.md); controls/cleanup PASS. |
| 50 | medium-r2-cw14-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw14-current-dd/worksheet.md); controls/cleanup PASS. |
| 51 | medium-r2-cw14-discovery | COMPLETED; discovery PASS (both targets), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw14-discovery/worksheet.md); controls/cleanup PASS. |
| 52 | medium-r2-cw17-contract | COMPLETED; semantic FAIL (response exception), body consistency/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw17-contract/worksheet.md); controls/cleanup PASS. |
| 53 | medium-r2-cw18-contract | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r2-cw18-contract/worksheet.md); controls/cleanup PASS. |
| 54 | medium-r2-cw18-discovery | COMPLETED; discovery PASS (bundled CW read), fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r2-cw18-discovery/worksheet.md); controls/cleanup PASS. |
| 55 | medium-r3-cw01-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw01-no-dd/worksheet.md); controls/cleanup PASS. |
| 56 | medium-r3-cw01-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw01-current-dd/worksheet.md); controls/cleanup PASS. |
| 57 | medium-r3-cw02-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw02-no-dd/worksheet.md); controls/cleanup PASS. |
| 58 | medium-r3-cw02-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw02-current-dd/worksheet.md); controls/cleanup PASS. |
| 59 | medium-r3-cw03-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw03-no-dd/worksheet.md); controls/cleanup PASS. |
| 60 | medium-r3-cw03-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw03-current-dd/worksheet.md); controls/cleanup PASS. |
| 61 | medium-r3-cw04-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw04-no-dd/worksheet.md); controls/cleanup PASS. |
| 62 | medium-r3-cw04-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw04-current-dd/worksheet.md); controls/cleanup PASS. |
| 63 | medium-r3-cw05-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw05-no-dd/worksheet.md); controls/cleanup PASS. |
| 64 | medium-r3-cw05-current-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw05-current-dd/worksheet.md); controls/cleanup PASS. |
| 65 | medium-r3-cw06-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw06-no-dd/worksheet.md); controls/cleanup PASS. |
| 66 | medium-r3-cw06-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r3-cw06-current-dd/worksheet.md); controls/cleanup PASS. |
| 67 | medium-r3-cw07-no-dd | COMPLETED; transport/prose PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw07-no-dd/worksheet.md); controls/cleanup PASS. |
| 68 | medium-r3-cw07-current-dd | COMPLETED; transport/prose PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw07-current-dd/worksheet.md); controls/cleanup PASS. |
| 69 | medium-r3-cw09-description | COMPLETED; semantic FAIL (target composition), fidelity FAIL (narration), source faithfulness PASS, protocol N/A; [worksheet](attempts/medium-r3-cw09-description/worksheet.md); controls/cleanup PASS. |
| 70 | medium-r3-cw10-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw10-contract/worksheet.md); controls/cleanup PASS. |
| 71 | medium-r3-cw11-description | COMPLETED; semantic FAIL (target composition), source faithfulness/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw11-description/worksheet.md); controls/cleanup PASS. |
| 72 | medium-r3-cw12-contract | COMPLETED; semantic FAIL (absent ownership), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw12-contract/worksheet.md); controls/cleanup PASS. |
| 73 | medium-r3-cw13-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw13-no-dd/worksheet.md); controls/cleanup PASS. |
| 74 | medium-r3-cw13-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r3-cw13-current-dd/worksheet.md); controls/cleanup PASS. |
| 75 | medium-r3-cw13-discovery | COMPLETED; discovery PASS (both targets), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw13-discovery/worksheet.md); controls/cleanup PASS. |
| 76 | medium-r3-cw14-no-dd | COMPLETED; semantic PASS, fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw14-no-dd/worksheet.md); controls/cleanup PASS. |
| 77 | medium-r3-cw14-current-dd | COMPLETED; semantic PASS, fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r3-cw14-current-dd/worksheet.md); controls/cleanup PASS. |
| 78 | medium-r3-cw14-discovery | COMPLETED; discovery PASS (both targets), fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw14-discovery/worksheet.md); controls/cleanup PASS. |
| 79 | medium-r3-cw17-contract | COMPLETED; semantic FAIL (scope exception absent), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw17-contract/worksheet.md); controls/cleanup PASS. |
| 80 | medium-r3-cw18-contract | COMPLETED; semantic PASS (file scope), extraction/fidelity PASS, protocol N/A; [worksheet](attempts/medium-r3-cw18-contract/worksheet.md); controls/cleanup PASS. |
| 81 | medium-r3-cw18-discovery | COMPLETED; discovery PASS (bundled CW read before file generation), fidelity FAIL (narration), protocol N/A; [worksheet](attempts/medium-r3-cw18-discovery/worksheet.md); controls/cleanup PASS. |
