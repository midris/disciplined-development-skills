# CW catalog qualification and reuse

Status: PROVIDER-FREE QUALIFICATION PASSES for the approved full-CW mapping.
No model invocation, actual-authentication access, rescoring, candidate evaluation or evidence promotion occurred.
Worktree: /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design
Branch: feature/cw-validation-design.
Input freeze and exact-command approval remain separate gates.

## Evidence

- [CLI version](cli-version.txt), [stderr](cli-version-stderr.txt) and [digest](cli-sha256.txt) match the retained medium-run reference: Codex 0.153.4, SHA-256 b973d440acac501fd2594a43e7ca9ce41e0a65b9dfb28d0d7a7837c99e1261e3.
  The version-only PATH-alias warning is unchanged; no fallback executable was used.
- [Reuse audit](reuse-audit.json), produced by [reuse-audit.py](reuse-audit.py): all 18 original bundles match their tied captures, config/prompt/fixture bytes, prelaunch hashes, artifact hashes, current adapter argv, completed trace envelopes and absent private runtimes.
  Each record links its unchanged original worksheet, result, timestamp and input revision.
- [Network controls](network-controls.json): loopback bind succeeds on the host and fails with PermissionError under [the deny-network policy](no-network.sb).
- [Catalog audit](native-v2/audit.json), [stdout](catalog-v2-stdout.txt) and [script](catalog-audit-v2.py): ordinary current-DD has 16 entries, authoring no-DD nine, authoring current-DD 18, and description-only seven.
  Every supplied native entry resolves to its declared fixture path.
  Removing only the expected DD/authoring catalog entries and substituting exact disposable paths/message IDs/timestamps produces equal common messages across all four setups.
  All 60 bootstrap files match across setups and the retained extension qualification.
  Required shell reads and private-runtime cleanup pass.
- [Final checks](final-checks.json), [stdout](final-checks-v2-stdout.txt) and [script](final-checks-v2.py): versus the retained common prompt, only the September 7→8 environment date and diagnostic-only user sentence differ.
  These are disclosed substitutions, not changes to scenario text or hidden normalization.
  CW-09/11, CW-13/14 pairs and their discovery counterparts have identical fixture target/hash maps within each qualified group.
- [CW-18 write output](write-stdout.txt) is WRITE_READ_OK, with empty [stderr](write-stderr.txt).
  A deterministic Python command in the installed Codex workspace-write sandbox created and reread only clothing-swap-guide.md in the prepared CW-18 fixture.
  The runner's existing inventory helper records its bytes/hash; all declared inputs remain unchanged.
  The credential-free test profile was removed after inspecting its empty lock and three CLI alias symlinks; symlink targets were not removed.

## Qualification scope

Reuse the [retained control reconciliation](/private/tmp/skilltest-cw-baseline.ksDeiD/preflight/reconciliation.md) and its original real read/file-change/cleanup evidence.
The runner, runtime, adapter and their flags are unchanged from those calls.
Private HOME/CODEX_HOME creation, fresh fixture Git boundary and isolation from competing user/global/config/ancestor instructions use those same mechanisms; new native-catalog evidence checks the changed substrate rather than assuming copied files establish discoverability.

The authoring fixtures provide writing-skills, its testing reference and required TDD background.
Their full bytes were inspected.
Platform setup, graph rendering, persuasion research, worked examples and writing-good-tests guidance concern setup or actual authoring/test implementation, not these read-only next-action decisions.
The testing reference's discipline-only scope does not replace the main writing-skills body's explicit reference retrieval/application/gap-testing guidance.
No executed-authoring or dependency closure for a real edit is claimed.
A subject reaching a genuinely required missing dependency still stops the affected collection for disposition.

Description files are task data, not native skill bodies.
The three descriptions match the frozen source metadata as established in the preparation audit; both description configs use identical bytes/targets.
Do not infer native CW availability from this description-only setup.

The CW-18 check exercises local file creation through the installed sandbox and the runner's retained-inventory mechanism.
Together with the unchanged real Codex file-change qualification, it requires no additional paid setup probe for this ordinary Markdown destination.
It does not prove a model will choose the skill, produce the requested prose or respect every boundary; inspect each actual trace and artifact.
Debug prompt-input does not exercise exec-only flags, model behavior or hidden inputs.
Automatic shell-startup reads, common provider skills and hidden-provider limits remain disclosed; this is not universal filesystem isolation.

## Reuse disposition

Reuse all six complete three-observation sets: CW-08 no-DD/current-DD, CW-19 no-DD/current-DD, CW-01 discovery and CW-17 discovery.
Their 18 records stay at [the original summary](/private/tmp/skilltest-cw-baseline.ksDeiD/summary.md), with unchanged scores, timestamps and owner-acceptance status.
They were collected at 6fb4780fce37710a76116dbbeaa832a6a42289cd.

The source scenarios, selected configs/prompts/rubrics, routine scoring/recovery guide, charter and methodology are unchanged.
The CW runbook/spec changes expand inventory and qualification for new cases, clarify reuse and defer candidate work; they do not change those six conditions' scoring or permitted actions.
The CW-06 correction affects no reused condition.
Fixed order and noncontemporaneous collection remain sampling limits, not randomized causal evidence.

The full set is 99 observations: 18 reused plus 81 new Codex / gpt-5.6-sol / medium observations.
Keep all three observations of each condition, including FAILs and fidelity caveats.
This qualification/reuse decision is not owner acceptance of the results or permission to invoke the remaining commands.

## Audit interruptions

The first catalog script stopped at the deterministic write step: nesting Codex's Seatbelt sandbox inside the deny-network Seatbelt policy returned sandbox_apply: Operation not permitted before Python ran.
[Original script](catalog-audit.py), [error](catalog-stderr.txt) and [per-command evidence](native/ordinary-write-command.json) remain retained; that runtime was cleaned up.
The corrected catalog audit keeps network denial and omits that nested step.
The separate credential-free Codex-sandbox write succeeded without nesting, with network disabled in its config.
This is an audit arrangement issue, not a skill failure or INFRA_RETRY.

The first final-check script's regular-file count followed the CLI's three alias symlinks.
[Its error](final-checks-stderr.txt) is retained.
After inspecting each link and target, final-checks-v2 distinguished links from regular files and safely removed only the exact disposable profile.
No production code or test inputs changed for either audit correction.

Hook verification: 263 passed, three skipped in 26.26s.
No runner/environment changes require repeating the unchanged offline runner suite.

