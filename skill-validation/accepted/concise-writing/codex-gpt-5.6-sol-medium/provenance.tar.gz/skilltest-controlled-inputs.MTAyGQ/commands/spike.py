import hashlib, json, os, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path('/private/tmp/skilltest-controlled-inputs.MTAyGQ')
WORKTREE = pathlib.Path('/Users/simon/work/personal/disciplined-development-skills/.worktrees/skilltest-input-isolation-spike')
PLAN = WORKTREE / 'plans/2026-09-05-skilltest-provider-input-isolation.md'
WRAPPER = str(ROOT / 'commands/run-private.sh')
PROMPT = (ROOT / 'commands/provider-prompt.txt').read_text()

def record(label, argv, cwd):
    folder = ROOT / 'outputs' / label
    folder.mkdir()  # Duplicate labels fail closed; earlier evidence never overwritten.
    (folder / 'command.json').write_text(json.dumps({'argv': argv, 'cwd': str(cwd)}, indent=2) + '\n')
    try:
        proc = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=45)
        out, err, status = proc.stdout, proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        out, err, status = exc.stdout or b'', exc.stderr or b'', 'TIMEOUT'
    (folder / 'stdout').write_bytes(out)
    (folder / 'stderr').write_bytes(err)
    (folder / 'status.json').write_text(json.dumps(status) + '\n')
    print(f'{label}: {status}', flush=True)
    return status

def prepare(trial, arm):
    base = ROOT / 'runtime' / trial
    for name in ('home', 'codex-home', 'tmp', 'project'):
        (base / name).mkdir(parents=True, mode=0o700)
    project = base / 'project'
    (project / '.agents/skills/discovery-probe').mkdir(parents=True)
    (project / 'fixture').mkdir()
    shutil.copyfile(ROOT / f'fixtures/{arm}/SKILL.md', project / '.agents/skills/discovery-probe/SKILL.md')
    shutil.copyfile(ROOT / 'fixtures/common/AGENTS.md', project / 'AGENTS.md')
    shutil.copyfile(ROOT / 'fixtures/common/allowed.txt', project / 'fixture/allowed.txt')
    shutil.copyfile(ROOT / 'fixtures/ambient/parent.md', base / 'AGENTS.md')
    assert record(trial + '-git-init', [WRAPPER, trial, '/usr/bin/git', 'init', '--quiet', '--initial-branch=main'], project) == 0
    return base, project

def debug(trial, cwd):
    return record(trial + '-debug', [WRAPPER, trial, '/opt/homebrew/bin/codex', 'debug', 'prompt-input', '-c', 'model="gpt-5.6-sol"', '-c', 'model_reasoning_effort="high"', '-c', 'shell_environment_policy.inherit="none"', PROMPT], cwd)

if __name__ == '__main__':
    os.umask(0o077)
    phase = sys.argv[1]
    if phase == 'prepare':
        (ROOT / 'outputs').mkdir()
        (ROOT / 'runtime').mkdir(mode=0o700)
        (ROOT / 'commands/run-private.sh').chmod(0o700)
        metadata = {'base_commit': 'c39fd41d0009370282b6ac9773c38cf5ad70852c', 'plan_sha256': hashlib.sha256(PLAN.read_bytes()).hexdigest(), 'launcher': 'Codex CLI in iTerm2 on macOS', 'allocation': 'mktemp -d /private/tmp/skilltest-controlled-inputs.XXXXXX', 'allocation_status': 0}
        (ROOT / 'outputs/metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
        for trial, arm in [('control','A'), ('parent','A'), ('A1','A'), ('B1','B'), ('B2','B'), ('A2','A')]:
            prepare(trial, arm)
        base = ROOT / 'runtime/control'
        (base / 'home/.agents/skills/discovery-probe').mkdir(parents=True)
        shutil.copyfile(ROOT / 'fixtures/ambient/SKILL.md', base / 'home/.agents/skills/discovery-probe/SKILL.md')
        for filename in ('AGENTS.md', 'config.toml'):
            shutil.copyfile(ROOT / f'fixtures/ambient/{filename}', base / 'codex-home' / filename)
        parent = ROOT / 'runtime/parent/project'
        shutil.copyfile(ROOT / 'fixtures/ambient/parent.md', parent / 'AGENTS.md')
        (parent / 'nested').mkdir()
        record('platform', [WRAPPER,'A1','/bin/sh','-c','date -u; sw_vers; uname -m'], ROOT)
        record('version', [WRAPPER,'A1','codex','--version'], ROOT)
        record('exec-help', [WRAPPER,'A1','codex','exec','--help'], ROOT)
        record('debug-help', [WRAPPER,'A1','codex','debug','prompt-input','--help'], ROOT)
        record('initial-main-status', ['/usr/bin/git','status','--porcelain=v1'], WORKTREE.parent.parent)
        record('initial-worktree-status', ['/usr/bin/git','status','--porcelain=v1'], WORKTREE)
        roots = ['/Users/simon/.agents/skills','/Users/simon/.codex/skills','/Users/simon/.codex/plugins','/etc/codex/skills','/etc/codex/config.toml','/etc/codex/requirements.toml']
        (ROOT / 'outputs/host-root-metadata.json').write_text(json.dumps({p: {'exists': pathlib.Path(p).exists(), 'symlink': pathlib.Path(p).is_symlink()} for p in roots}, indent=2) + '\n')
    elif phase == 'controls':
        debug('control', ROOT / 'runtime/control/project')
        debug('parent', ROOT / 'runtime/parent/project/nested')
    elif phase == 'compare':
        for trial in ('A1','B1','B2','A2'):
            debug(trial, ROOT / 'runtime' / trial / 'project')
    else:
        raise SystemExit('Unknown phase')
