#!/bin/sh
set -eu
case "$1" in control|parent|A1|B1|B2|A2|integration) trial="$1";; *) exit 64;; esac
shift
exec /usr/bin/env -i HOME="/private/tmp/skilltest-controlled-inputs.MTAyGQ/runtime/$trial/home" CODEX_HOME="/private/tmp/skilltest-controlled-inputs.MTAyGQ/runtime/$trial/codex-home" TMPDIR="/private/tmp/skilltest-controlled-inputs.MTAyGQ/runtime/$trial/tmp" PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin "$@"
