# CW baseline: exact-command approval and results ledger

Status: OWNER-ACCEPTED on 2026-09-08 as the 18 reused observations within the complete 99-observation CW baseline.
The [complete-set acceptance record](/private/tmp/skilltest-cw-baseline.bOn8Dx/summary.md) governs that later disposition; original scoring-time worksheet text, scores and provenance remain unchanged.
Approved document SHA-256 before this status update: `75303b1a082b44e8dd1f4bf8d8a78818d26612d5d2a444b4078548b6ce1bb598`.
No additional provider calls, retries, candidate edits or evidence promotion are authorized.
This list replaces the superseded 54-command proposal; only the 18 medium commands below are approved.
The scratch package is reused because its runs and attempt directories are verified empty; unused low/high attempt directories confer no execution authority.

## Frozen execution contract

- Working directory for every command: `/Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design`.
- Branch: `feature/cw-validation-design`; frozen full revision: `6fb4780fce37710a76116dbbeaa832a6a42289cd` (pushed).
- Provider/model: `codex / gpt-5.6-sol`.
- Effort: medium only; three repetitions per condition.
- Count: 18 observations; 12 behavior and six discovery.
- Order: repetitions 1–3 each visit all six rows in runbook order.
- Serial execution only; no adaptive stopping based on judgeable verdicts.
- Scratch: `/private/tmp/skilltest-cw-baseline.ksDeiD`; bundles under `runs/`, distinct command/provenance/worksheet captures under `attempts/`.
- Fixed qualified CLI capture directory: `/private/tmp/skilltest-cw-baseline.ksDeiD/preflight`.
- CLI: `/opt/homebrew/bin/codex`, `codex-cli 0.153.4`, SHA-256 `b973d440acac501fd2594a43e7ca9ce41e0a65b9dfb28d0d7a7837c99e1261e3`.
- Qualification: [reconciled controls](preflight/reconciliation.md); [selected medium-config audit](preflight/medium-schedule-audit.txt); [retained full preparation audit](preflight/input-audit.json).
- Procedure: [frozen CW runbook](/Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/cw-runbook.md).
- Per-attempt version/digest checks, private-runtime isolation, full-trace scoring, protected-file checks and cleanup verification remain mandatory.
- Each attempt directory has been created empty. Do not recreate or overwrite it blindly.
- Only understood infrastructure-only failures qualify for exact unchanged-command retries under the linked runbook; retain excluded captures in scratch.
- No low/high, Astra/Terra/Claude calls, candidate authoring, broader collection or baseline promotion is authorized.
- These commands invoke the one-run runner. Frozen configs select the model/effort and the production adapter supplies the qualified CLI isolation options; no extra harness or profile is introduced.
- The checked-in collection/owner-review checkpoint is reconciled and pushed at `894e79ed519d98afd3ad3c42780c001fd5621e66`; only three status/navigation documents changed after the frozen collection revision.

## Results for owner review

All observations use Codex / gpt-5.6-sol / medium and the fixed CLI/version/digest above.
Counts are separate by condition and purpose; they are three observations each, not precise effectiveness estimates.

| Purpose / condition | PASS | FAIL | INCONCLUSIVE | Evaluable | Fidelity FAIL |
|---|---|---|---|---|---|
| CW-08 behavior / no-DD | 3 | 0 | 0 | 3 | 0 |
| CW-08 behavior / current-DD | 3 | 0 | 0 | 3 | 3 |
| CW-19 behavior / no-DD | 0 | 3 | 0 | 3 | 0 |
| CW-19 behavior / current-DD | 2 | 1 | 0 | 3 | 2 |
| CW-01 positive discovery / current-DD | 3 | 0 | 0 | 3 | 1 |
| CW-17 non-trigger discovery / current-DD | 1 | 2 | 0 | 3 | 0 |

- CW-08 is a passing no-DD control, not behavioral RED; these runs show no semantic separation between conditions on that task.
- CW-19 no-DD failed padding removal in all three observations by redundantly restating the GO-before-promotion rule; its conservation criteria passed.
- CW-19 current-DD removed that redundancy in all three observations, but repetition 2 replaced exact escalation thresholds with “either metric breaches its limit,” failing the rubric's mismatch-equality boundary.
- Positive discovery loaded CW in all three observations: alongside DD doctrine in repetition 1, directly in repetitions 2–3.
- Non-trigger discovery selected/read CW in repetitions 2–3, alongside DD doctrine and additionally DR in repetition 3; repetition 1 had no observed selection. These are scoped visible-selection judgments, not proof of hidden use/non-use.
- Six separate fidelity failures were prohibited narration: all CW-08/current-DD runs, CW-19/current-DD repetitions 2–3, and positive-discovery repetition 3. The CW-17 rubric does not impose that no-narration requirement.

All 18 runs completed with empty provider/command stderr, matched prelaunch/final input hashes and exact argv, complete observable traces, unchanged protected fixtures, empty evidence directories and verified private-runtime cleanup.
There were no infrastructure retries, excluded observations, invalid scenarios, unresolved cleanup or changed task inputs.
Every per-attempt CLI capture matches the fixed reference; the version command's previously disclosed PATH-alias warning is retained and non-blocking.
The [handoff audit](preflight/handoff-audit.txt) checked all 18 records, preserved worksheet mechanical fields, 204 worksheet links, serial order, empty runtime leftovers and the unchanged frozen worktree.
The fresh handoff hook suite passed 263 tests with three skips; the unchanged runner retains its frozen-input 231-test verification.

No process or runner change was required by this batch.
The observations support retaining full-trace scoring and separate behavior/discovery/fidelity judgments.
Owner acceptance is complete; the live CW design now tracks evidence preservation and preparation of the existing candidate. This batch authorizes no additional run.
Later authoring must identify the targeted no-DD failure and agree repetitions/acceptance rules; the current-DD threshold failure alone does not establish no-DD RED for that criterion.

## Results ledger

Pending rows have not run. Record exit status, stdout's exact bundle path, capture references and completed worksheet after each approved command; do not infer a bundle by newest timestamp.
Worksheet scenario paths below are relative to the frozen worktree; medium configs use these shared rubrics, not the config directory.
Keep criterion detail in each worksheet; summarize verdict counts by scenario/condition at Sol medium, with exclusions and fidelity/readability caveats separate.

| # | Attempt label | Worksheet scenario | Status / bundle / worksheet |
|---|---|---|---|
| 1 | medium-r1-cw08-no-dd | `skill-validation/pilot/cw-08/no-dd` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T023433098Z-cw-08-no-dd-medium-e62bc4df-0c00-4406-adb6-8545307443d2-_xc9rgo2); [worksheet](attempts/medium-r1-cw08-no-dd/worksheet.md); [CLI](attempts/medium-r1-cw08-no-dd/preflight.json); [command output](attempts/medium-r1-cw08-no-dd/command-stdout.txt) |
| 2 | medium-r1-cw08-current-dd | `skill-validation/pilot/cw-08/current-dd` | PASS; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T023700488Z-cw-08-current-dd-medium-1531ee9d-18aa-45d0-b9c0-164b9fb7fd8d-1x6b9ik6); [worksheet](attempts/medium-r1-cw08-current-dd/worksheet.md); [CLI](attempts/medium-r1-cw08-current-dd/preflight.json); [command output](attempts/medium-r1-cw08-current-dd/command-stdout.txt) |
| 3 | medium-r1-cw19-no-dd | `skill-validation/pilot/cw-19/no-dd` | FAIL; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T023851967Z-cw-19-no-dd-medium-d9aaf813-5a76-4c50-a563-9aff7277a02c-ppp9mjd1); [worksheet](attempts/medium-r1-cw19-no-dd/worksheet.md); [CLI](attempts/medium-r1-cw19-no-dd/preflight.json); [command output](attempts/medium-r1-cw19-no-dd/command-stdout.txt) |
| 4 | medium-r1-cw19-current-dd | `skill-validation/pilot/cw-19/current-dd` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024036427Z-cw-19-current-dd-medium-b034590d-92d5-4220-9333-da8d1c6e2417-gyg_b_5w); [worksheet](attempts/medium-r1-cw19-current-dd/worksheet.md); [CLI](attempts/medium-r1-cw19-current-dd/preflight.json); [command output](attempts/medium-r1-cw19-current-dd/command-stdout.txt) |
| 5 | medium-r1-cw01-discovery | `skill-validation/pilot/cw-01/discovery` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024156649Z-cw-01-discovery-medium-0e0204cf-d204-458f-87b5-b04bba96e3c2-_b5pia31); [worksheet](attempts/medium-r1-cw01-discovery/worksheet.md); [CLI](attempts/medium-r1-cw01-discovery/preflight.json); [command output](attempts/medium-r1-cw01-discovery/command-stdout.txt) |
| 6 | medium-r1-cw17-discovery | `skill-validation/pilot/cw-17/discovery` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024255855Z-cw-17-discovery-medium-2ea8afcf-2a6a-4d07-8fdb-17161df6a00d-hrpoc_cd); [worksheet](attempts/medium-r1-cw17-discovery/worksheet.md); [CLI](attempts/medium-r1-cw17-discovery/preflight.json); [command output](attempts/medium-r1-cw17-discovery/command-stdout.txt) |
| 7 | medium-r2-cw08-no-dd | `skill-validation/pilot/cw-08/no-dd` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024448842Z-cw-08-no-dd-medium-33410397-4110-4413-8da3-ee10c2c4a8c9-zxjxx1c7); [worksheet](attempts/medium-r2-cw08-no-dd/worksheet.md); [CLI](attempts/medium-r2-cw08-no-dd/preflight.json); [command output](attempts/medium-r2-cw08-no-dd/command-stdout.txt) |
| 8 | medium-r2-cw08-current-dd | `skill-validation/pilot/cw-08/current-dd` | PASS; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T024546263Z-cw-08-current-dd-medium-204fcc0e-5bf3-47cb-a002-660c68979863-dbx4kz2n); [worksheet](attempts/medium-r2-cw08-current-dd/worksheet.md); [CLI](attempts/medium-r2-cw08-current-dd/preflight.json); [command output](attempts/medium-r2-cw08-current-dd/command-stdout.txt) |
| 9 | medium-r2-cw19-no-dd | `skill-validation/pilot/cw-19/no-dd` | FAIL; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024636108Z-cw-19-no-dd-medium-6d5862de-653c-4ee1-a0ff-6cfd8c1ea97e-v3_q51s2); [worksheet](attempts/medium-r2-cw19-no-dd/worksheet.md); [CLI](attempts/medium-r2-cw19-no-dd/preflight.json); [command output](attempts/medium-r2-cw19-no-dd/command-stdout.txt) |
| 10 | medium-r2-cw19-current-dd | `skill-validation/pilot/cw-19/current-dd` | FAIL; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T024719977Z-cw-19-current-dd-medium-b9bacf69-a3b2-455f-b5d4-00225f02efc1-zjhtsajn); [worksheet](attempts/medium-r2-cw19-current-dd/worksheet.md); [CLI](attempts/medium-r2-cw19-current-dd/preflight.json); [command output](attempts/medium-r2-cw19-current-dd/command-stdout.txt) |
| 11 | medium-r2-cw01-discovery | `skill-validation/pilot/cw-01/discovery` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024832019Z-cw-01-discovery-medium-46f57a0c-aaa1-4e52-a06b-2d6e801ca887-_3vf9gkx); [worksheet](attempts/medium-r2-cw01-discovery/worksheet.md); [CLI](attempts/medium-r2-cw01-discovery/preflight.json); [command output](attempts/medium-r2-cw01-discovery/command-stdout.txt) |
| 12 | medium-r2-cw17-discovery | `skill-validation/pilot/cw-17/discovery` | FAIL; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T024947428Z-cw-17-discovery-medium-28b41bdd-8af6-4fd9-b16c-4c9444d8b3d3-lwbtssyn); [worksheet](attempts/medium-r2-cw17-discovery/worksheet.md); [CLI](attempts/medium-r2-cw17-discovery/preflight.json); [command output](attempts/medium-r2-cw17-discovery/command-stdout.txt) |
| 13 | medium-r3-cw08-no-dd | `skill-validation/pilot/cw-08/no-dd` | PASS; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T025149757Z-cw-08-no-dd-medium-873ad9a4-26cf-45c7-b4fa-06f3af933a78-4akrwnw8); [worksheet](attempts/medium-r3-cw08-no-dd/worksheet.md); [CLI](attempts/medium-r3-cw08-no-dd/preflight.json); [command output](attempts/medium-r3-cw08-no-dd/command-stdout.txt) |
| 14 | medium-r3-cw08-current-dd | `skill-validation/pilot/cw-08/current-dd` | PASS; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T025220926Z-cw-08-current-dd-medium-3feb790b-4258-4e4d-8bed-852924986f92-ppkuphub); [worksheet](attempts/medium-r3-cw08-current-dd/worksheet.md); [CLI](attempts/medium-r3-cw08-current-dd/preflight.json); [command output](attempts/medium-r3-cw08-current-dd/command-stdout.txt) |
| 15 | medium-r3-cw19-no-dd | `skill-validation/pilot/cw-19/no-dd` | FAIL; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T025306797Z-cw-19-no-dd-medium-7e8998b1-d1f0-42ce-9a76-7c509c143c33-lpzdq7dl); [worksheet](attempts/medium-r3-cw19-no-dd/worksheet.md); [CLI](attempts/medium-r3-cw19-no-dd/preflight.json); [command output](attempts/medium-r3-cw19-no-dd/command-stdout.txt) |
| 16 | medium-r3-cw19-current-dd | `skill-validation/pilot/cw-19/current-dd` | PASS; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T025350681Z-cw-19-current-dd-medium-4664dce8-59bc-4159-b2fc-be155da743ed-c9io6_57); [worksheet](attempts/medium-r3-cw19-current-dd/worksheet.md); [CLI](attempts/medium-r3-cw19-current-dd/preflight.json); [command output](attempts/medium-r3-cw19-current-dd/command-stdout.txt) |
| 17 | medium-r3-cw01-discovery | `skill-validation/pilot/cw-01/discovery` | PASS; fidelity FAIL; exit 0; [bundle](runs/skilltest-runs/20260908T025452298Z-cw-01-discovery-medium-da5fe7b1-aed2-40e8-8067-cfff6d6bf6cf-8enqlv8f); [worksheet](attempts/medium-r3-cw01-discovery/worksheet.md); [CLI](attempts/medium-r3-cw01-discovery/preflight.json); [command output](attempts/medium-r3-cw01-discovery/command-stdout.txt) |
| 18 | medium-r3-cw17-discovery | `skill-validation/pilot/cw-17/discovery` | FAIL; fidelity PASS; exit 0; [bundle](runs/skilltest-runs/20260908T025549004Z-cw-17-discovery-medium-d2251cca-3692-4f7a-9c24-838204d05e5d-6y0kyr0b); [worksheet](attempts/medium-r3-cw17-discovery/worksheet.md); [CLI](attempts/medium-r3-cw17-discovery/preflight.json); [command output](attempts/medium-r3-cw17-discovery/command-stdout.txt) |

## Complete approved commands

All commands below run from the working directory stated above. No loops, placeholders or implicit extra provider calls are included.

### 1. medium-r1-cw08-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw08-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw08-no-dd/command-stderr.txt
```

### 2. medium-r1-cw08-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw08-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw08-current-dd/command-stderr.txt
```

### 3. medium-r1-cw19-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw19-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw19-no-dd/command-stderr.txt
```

### 4. medium-r1-cw19-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw19-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw19-current-dd/command-stderr.txt
```

### 5. medium-r1-cw01-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw01-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw01-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw01-discovery/command-stderr.txt
```

### 6. medium-r1-cw17-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 1.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw17-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw17-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r1-cw17-discovery/command-stderr.txt
```

### 7. medium-r2-cw08-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw08-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw08-no-dd/command-stderr.txt
```

### 8. medium-r2-cw08-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw08-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw08-current-dd/command-stderr.txt
```

### 9. medium-r2-cw19-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw19-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw19-no-dd/command-stderr.txt
```

### 10. medium-r2-cw19-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw19-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw19-current-dd/command-stderr.txt
```

### 11. medium-r2-cw01-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw01-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw01-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw01-discovery/command-stderr.txt
```

### 12. medium-r2-cw17-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 2.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw17-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw17-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r2-cw17-discovery/command-stderr.txt
```

### 13. medium-r3-cw08-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw08-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw08-no-dd/command-stderr.txt
```

### 14. medium-r3-cw08-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw08-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw08-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw08-current-dd/command-stderr.txt
```

### 15. medium-r3-cw19-no-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-no-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw19-no-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw19-no-dd/command-stderr.txt
```

### 16. medium-r3-cw19-current-dd

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw19-current-dd.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw19-current-dd/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw19-current-dd/command-stderr.txt
```

### 17. medium-r3-cw01-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw01-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw01-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw01-discovery/command-stderr.txt
```

### 18. medium-r3-cw17-discovery

Provider: codex; model: gpt-5.6-sol; effort: medium; repetition: 3.

```sh
/usr/bin/env TMPDIR=/private/tmp/skilltest-cw-baseline.ksDeiD/runs PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/runner/.venv/bin/skilltest run /Users/simon/work/personal/disciplined-development-skills/.worktrees/cw-validation-design/skill-validation/pilot/efforts/medium/cw17-discovery.json > /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw17-discovery/command-stdout.txt 2> /private/tmp/skilltest-cw-baseline.ksDeiD/attempts/medium-r3-cw17-discovery/command-stderr.txt
```
