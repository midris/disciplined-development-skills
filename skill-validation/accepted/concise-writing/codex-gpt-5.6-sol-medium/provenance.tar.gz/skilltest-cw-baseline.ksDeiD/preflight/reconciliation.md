# CW baseline qualification reuse

Provider-free controls reconciled for the approved medium-only 18-run schedule; no model command or authentication call has been invoked.
The fixed executable is `/opt/homebrew/bin/codex`, version `codex-cli 0.153.4`, SHA-256 `b973d440acac501fd2594a43e7ca9ce41e0a65b9dfb28d0d7a7837c99e1261e3`.
Fresh [version](cli-version.txt) and [digest](cli-sha256.txt) match the extension's fixed captures; [version stderr](version-stderr.txt) contains only the previously disclosed PATH-alias permission warning.
These are preflight reference captures, not per-run CLI provenance; recapture immediately before every attempt.

## Evidence and disposition

Use the retained [extension control reconciliation](/private/tmp/skilltest-sol-low-pilot.Lunoau/extension.xWS8Q2/preflight/reconciliation.md) and [CW observation-boundary check](/private/tmp/skilltest-sol-low-pilot.Lunoau/cw-inputs.veav95/preflight/reconciliation-audit-output.json).
The retained [18-config audit](input-audit.json) was run with the retained [provider-free command](input-audit-command.txt) before the schedule was narrowed.
Its 54 planned observations are superseded, not executed results; the [medium-only schedule audit](medium-schedule-audit.txt) confirms the six selected configs and every subject/scoring input are unchanged.
It prepared only prompt/fixture workspaces; those audit directories have no provider result and are not scored observations or infrastructure attempts.
The first audit output capture was truncated by the controller's output limit; it is retained as `input-audit-truncated.txt`.
The unchanged provider-free audit was repeated with sufficient capture capacity; `input-audit.json` is the complete, parsed result.

| Required control | Reuse basis and scope |
|---|---|
| Competing user skill | Same private-profile creation and native roots; no host user skill/config is copied. Reuse the extension's surrogate controls. |
| Global and config instructions | Production adapter/runtime source matches real qualification at 0a22a44; same fixed flags, profile isolation and auth-copy boundary. CLI binary/version are unchanged. |
| Parent ancestry | Same fresh template-free fixture Git boundary; new tasks are inline prose, not additional parent instruction files. Worktree relocation does not change the temporary subject root mechanism. |
| Native catalog and supporting files | All 18 configs' declared guidance bytes match f28ea65; the same four common Superpowers files and nine DD bodies retain their targets. Reuse the seven/sixteen native-entry and 60-file bootstrap comparison. |
| Model/effort | Same model; use only the six audited medium configs. The earlier provider-free argv comparison verified changes limited to effort and per-run paths. The profile/catalog/local-read controls do not gain a new mechanism or dependency from that argument. This does not claim identical hidden provider context or behavior across efforts or transfer low-effort skill verdicts to medium. |
| Prose task and ordinary tools | Both new tasks use inline supplied facts and the already exercised local skill-read/response path. Quoted cutover commands are not executed; no new application/tool runtime is required. |
| Selection observability | Reuse the CW full-read/trace reconciliation and completed positive/non-trigger traces, not their skill verdicts. Full observable trace inspection and the frozen discovery rubrics remain required per run. No inferred hidden use/non-use. |
| Cleanup and writes | Same owned-process lifecycle and private runtime; existing real read/write/cleanup qualification remains relevant. These tasks permit no subject file writes. Verify protected files and exact cleanup evidence for each attempt. |

Date/timing, path and provider-internal variation remain disclosed incidental context; tasks contain no relative-to-today requirements.
Automatic shell-startup reads and hidden provider inputs retain the accepted observability limits; version equality alone does not establish qualification.
No additional paid qualification call is required for this unchanged mechanism under this scoped reuse decision.
Pause for missing/changed required controls or drift; treat expected skill differences as results, not setup defects.

## Verification

- Provider-free audit: six unchanged medium configs selected for 18 planned observations; frozen guidance matching and shared task inputs retained from the full preparation audit; no provider calls.
- Offline runner suite: the frozen-input verification passed 231; not repeated for this schedule-only amendment because runner code/environment are unchanged.
- Fresh hook suite: 263 passed, 3 skipped.
- Protected runner/skill/historical scenario/previous pilot input diffs: empty.

Exact command approval and per-run checks remain outstanding; this record grants no model invocation authority.
